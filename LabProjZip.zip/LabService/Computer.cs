using Newtonsoft.Json;
using LabDatabase;
using LabService;
using UserNamespace;
using Newtonsoft.Json.Linq;

public class Computer
{
    private static int _lastId = 0;
    public static DateOnly CreationDate { get; private set; }
    public int Id { get; private set; }
    public string? Name { get; private set; }
    public string? Description { get; private set; }
    public string? Specifics { get; private set; }
    public string? Status { get; private set; }
    //[JsonConverter (typeof(StringMatrixConverter))]

    /* public string BookingToString
    {
        get
        {
            if (Booking != null)
            {
                return ConvertToJson(Booking);
            }
            else return ConvertToJson(InitializeCalendar());
        }
        set
        {
            if (Booking != null) ConvertToJson(Booking);
        }
    } */
    public string[,]? Booking { get; set; }
    /* {
        get
        {
            if (BookingToString != null)
            {
                return ConvertFromJson(BookingToString);
            }
            else return InitializeCalendar();
        }
        set
        {
            if (BookingToString != null) ConvertFromJson(BookingToString);
        }
    } */

    public Computer(string name, string desc, string specs, string? status, string[,]? booking, string? creationDate)
    {
        Id = ++_lastId;
        Name = name;
        Description = desc;
        Specifics = specs;
        if (status != null && CheckStatus(status))
            Status = status;
        else Status = "available";
        if (booking != null && booking.GetLength(0) == 6 && booking.GetLength(1) == 10)
            Booking = booking;
        else Booking = InitializeCalendar();
        if (creationDate != null && _CreationDateCheck(creationDate)) CreationDate = DateOnly.FromDateTime(DateTime.Parse(creationDate));
        //  NOTE:   THERE'S ALREADY AN EXCEPTION FOR THE WRONG DateOnly FORMAT, SO IF A STRING PASSES THE _CreationDateCheck() 
        //          BUT IS IN A WRONG FORMAT THE SYSTEM WILL THROW AN EXCEPTION, OTHERWISE HE GOES THROUGH AND PARSE IT
        //          (OR TAKES THE DateTime.Now VALUE PARSED IN DateOnly)
        else CreationDate = DateOnly.FromDateTime(DateTime.Now);
    }

    private static string[,] InitializeCalendar()
    {
        string[,] Calendar = new string[6, 10];
        Calendar[0, 0] = "NOT BOOKABLE";
        Calendar[1, 0] = "Monday";
        Calendar[2, 0] = "Tuesday";
        Calendar[3, 0] = "Wednesday";
        Calendar[4, 0] = "Thursday";
        Calendar[5, 0] = "Friday";

        Calendar[0, 1] = "9-10";
        Calendar[0, 2] = "10-11";
        Calendar[0, 3] = "11-12";
        Calendar[0, 4] = "12-13";
        Calendar[0, 5] = "13-14";
        Calendar[0, 6] = "14-15";
        Calendar[0, 7] = "15-16";
        Calendar[0, 8] = "16-17";
        Calendar[0, 9] = "17-18";

        return Calendar;
    }

    private static bool CheckWeekday(string weekDay)
    {
        string[,] Calendar = InitializeCalendar();
        for (int i = 1; i >= 1 && i < Calendar.GetLength(0); i++)
        {
            if (weekDay == Calendar[i, 0])
                return true;
        }
        return false;
    }
    private static bool CheckTimeSlot(string timeSlot)
    {
        string[,] Calendar = InitializeCalendar();
        for (int i = 1; i >= 1 && i < Calendar.GetLength(1); i++)
        {
            if (timeSlot == Calendar[0, i])
                return true;
        }
        return false;
    }

    private static bool CheckStatus(string stat)
    {
        if (stat == "available" || stat == "maintenance" || stat == "out of order" || stat == "removed" || stat == "reserved")
        {
            return true;
        }
        else throw new Exception("STATUS NOT CORRECT");
    }
    private static bool _CreationDateCheck(string creationDate)
    {
        if (creationDate != null && creationDate.Length >= 8 && creationDate.Length <= 10) return true;
        else return false;
    }


    public void InsertBooking(string userEmail, string weekDay, string timeSlot)
    {
        if (Lab.GetAuthorizedUser(userEmail) && CheckWeekday(weekDay) && CheckTimeSlot(timeSlot))
        {
            int dayIndex = 0;
            int hourIndex = 0;
            for (int row = 1; Booking != null && row < Booking.GetLength(0); row++)
            {
                if (weekDay == Booking[row, 0])
                {
                    dayIndex = row;
                    break;
                }
            }
            for (int row = 1; Booking != null && row < Booking.GetLength(1); row++)
            {
                if (timeSlot == Booking[0, row])
                {
                    hourIndex = row;
                    break;
                }
            }
            if (dayIndex > 0 && hourIndex > 0)
            {
                if (Booking != null && Booking[dayIndex, hourIndex] == null)
                {
                    Booking[dayIndex, hourIndex] = userEmail;
                }
                else throw new Exception("TIMESLOT ALREADY BOOKED");
            }
            else throw new Exception("NOT ABLE TO FIND SPECIFIED TIMESLOT AND DAY");
        }
        else throw new Exception("USER NOT AUTHORIZED OR WRONG DAY SPECIFIED OR WRONG TIMESLOT SPECIFIED");
    }

    public void ClearCalendar()
    {
        Booking = InitializeCalendar();
    }

    private static string ConvertToJson(string[,] matrix)
    {
        // Creare un oggetto JArray per la conversione
        JArray jsonArray = new();

        // Ottieni le dimensioni della matrice
        int rows = matrix.GetLength(0);
        int columns = matrix.GetLength(1);

        // Popola l'oggetto JArray con i dati della matrice
        for (int i = 0; i < rows; i++)
        {
            JArray jsonRow = new();

            for (int j = 0; j < columns; j++)
            {
                jsonRow.Add(matrix[i, j]);
            }

            jsonArray.Add(jsonRow);
        }

        // Serializza l'oggetto JArray in una stringa JSON formattata
        return jsonArray.ToString(Formatting.Indented);
    }

    private static string[,] ConvertFromJson(string jsonString)
    {
        // Deserializza la stringa JSON in un array JArray
        JArray jsonArray = JArray.Parse(jsonString);

        // Ottieni le dimensioni della matrice
        int rows = jsonArray.Count;
        int columns = jsonArray[0].Count();

        // Inizializza la matrice
        string[,] matrix = new string[rows, columns];

        // Popola la matrice con i dati dal JArray
        for (int i = 0; i < rows; i++)
        {
            JArray jsonRow = (JArray)jsonArray[i];

            for (int j = 0; j < columns; j++)
            {
                matrix[i, j] = jsonRow[j].ToString();
            }
        }

        return matrix;
    }
}