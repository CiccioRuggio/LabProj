using System.Net.Security;
using UserNamespace;
using Newtonsoft.Json;
using System.ComponentModel;
using LabService;
using Newtonsoft.Json.Linq;
//using System.Text.Json;

namespace LabDatabase;
public class FileManager
{
    private static readonly string _firstPcsForInitialization = @"
        [
            {
                ""Id"": 1,
                ""CreationDate"": ""2023-11-16"",
                ""Name"": ""Computer1"",
                ""Description"": ""First desc"",
                ""Specifics"": ""Main specs: i7 12th gen, 16gb RAM, nvidia GeForce RTX 2060ti"",
                ""Status"": ""available"",
                ""Booking"": [
                    [""NOT BOOKABLE"", ""9-10"", ""10-11"", ""11-12"", ""12-13"", ""13-14"", ""14-15"", ""15-16"", ""16-17"", ""17-18""],
                    [""Monday"", null, null, null, null, null, null, null, null, null],
                    [""Tuesday"", null, null, null, null, null, null, null, null, null],
                    [""Wednesday"", null, null, null, null, null, null, null, null, null],
                    [""Thursday"", null, null, null, null, null, null, null, null, null],
                    [""Friday"", null, null, null, null, null, null, null, null, null]
                ]
            },
            {
                ""Id"": 2,
                ""CreationDate"": ""2023-11-16"",
                ""Name"": ""Computer2"",
                ""Description"": ""Second desc"",
                ""Specifics"": ""Main specs: i5 9th gen, 8gb RAM, nvidia GeForce RTX 1070ti"",
                ""Status"": ""available"",
                ""Booking"": [
                    [""NOT BOOKABLE"", ""9-10"", ""10-11"", ""11-12"", ""12-13"", ""13-14"", ""14-15"", ""15-16"", ""16-17"", ""17-18""],
                    [""Monday"", null, null, null, null, null, null, null, null, null],
                    [""Tuesday"", null, null, null, null, null, null, null, null, null],
                    [""Wednesday"", null, null, null, null, null, null, null, null, null],
                    [""Thursday"", null, null, null, null, null, null, null, null, null],
                    [""Friday"", null, null, null, null, null, null, null, null, null]
                ]
            }
        ]";
    private static readonly string FilePathLabs = "../LabService/Data/Labs.json";
    private static readonly string FilePathComputers = "../LabService/Data/Computers.json";

    private List<Computer> _computers { get; set; }
    private List<Lab> _labs { get; set; }

    public FileManager()
    {
        _computers = new();
        _labs = new();
        Computer c1 = new("Computer1", "First desc", "Main specs: i7 12th gen, 16gb RAM, nvidia GeForce RTX 2060ti", null, null, null);
        Computer c2 = new("Computer2", "Second desc", "Main specs: i5 9th gen, 8gb RAM, nvidia GeForce RTX 1070ti", null, null, null);
        Lab l1 = new();

        _computers.Add(c1);
        _computers.Add(c2);
        _labs.Add(l1);

        // string json = File.ReadAllText(_firsyPcsForInitialization);
        // _computers = JsonConvert.DeserializeObject<List<Computer>>(json);

        UpdateComputer();
        UpdateLab();

        _computers = LoadOrCreateComputers();
        _labs = LoadOrCreateLabs();

        /* LoadComputer();
        LoadLab(); */
    }

    public List<Computer> GetComputers()
    {
        return _computers;
    }
    public List<Lab> GetLabs()
    {
        return _labs;
    }

    public Computer FindComputer(int id)
    {
        foreach (Computer Computer in _computers)
        {
            if (Computer.Id == id)
            {
                return Computer;
            }
        }
        return null;
    }

    public Lab FindLab(int id)
    {
        foreach (Lab Lab in _labs)
        {
            if (Lab.Id == id)
            {
                return Lab;
            }
        }
        return null;
    }

    public bool CheckComputerExistence(Computer computer)
    {
        if (computer != null && computer.Id != 0 /* && computer.Id != null */)
        {
            if (FindComputer(computer.Id) != null && FindComputer(computer.Id).Id == computer.Id)
                return true;
        }
        return false;
    }

    public bool CheckLabExistence(Lab lab)
    {
        if (lab != null && lab.Id != 0/*  && Computer.Id != null */)
        {
            if (FindLab(lab.Id) != null && FindLab(lab.Id).Id == lab.Id)
                return true;
        }
        return false;
    }

    public void LoadComputer()
    {
        using StreamReader reader = new(FilePathComputers);
        string jsonread = reader.ReadToEnd();
        if (jsonread is not null)
            _computers = JsonConvert.DeserializeObject<List<Computer>>(jsonread);
    }
    public void LoadLab()
    {
        using StreamReader reader = new(FilePathLabs);
        string jsonread = reader.ReadToEnd();
        if (jsonread is not null)
            _labs = JsonConvert.DeserializeObject<List<Lab>>(jsonread);
    }

    public static List<Computer> LoadOrCreateComputers()
    {
        List<Computer> Computers = new();
        if (!File.Exists(FilePathComputers))
        {
            File.Create(FilePathComputers).Close();
            return Computers;
        }

        string json = File.ReadAllText(FilePathComputers);

        if (json.Length > 0)
        {
            //Computers = JsonConvert.DeserializeObject<List<Computer>>(json);
            //if (json.StartsWith("["))
            {
                try
                {
                    JArray jsonArray = JArray.Parse(json);
                    Computers = jsonArray.ToObject<List<Computer>>();
                }
                catch (JsonReaderException ex)
                {
                    // Gestisci l'eccezione o visualizza il messaggio per il debugging
                    Console.WriteLine($"Errore durante la deserializzazione del JSON: {ex.Message}");
                }
            }
        }
        //  Console.WriteLine(Computers.Count);     // USED FOR MANUAL DEBUGGING

        return Computers;
    }
    public static Computer LoadOrCreateSingleComputer()
    {
        Computer computer = new("DefaultName", "DefaultDesc", "DefaultSpecs", null, null, null);
        if (!File.Exists(FilePathComputers))
        {
            File.Create(FilePathComputers).Close();
            return computer;
        }

        string json = File.ReadAllText(FilePathComputers);

        if (json.Length > 0)
        {
            computer = JsonConvert.DeserializeObject<Computer>(json);
        }
        //  Console.WriteLine(Computers.Count);     // USED FOR MANUAL DEBUGGING

        return computer;
    }
    public static List<Lab> LoadOrCreateLabs()
    {
        List<Lab> Labs = new();
        if (!File.Exists(FilePathLabs))
        {
            File.Create(FilePathLabs).Close();
            return Labs;
        }

        string json = File.ReadAllText(FilePathLabs);

        if (json.Length > 0)
        {
            Labs = JsonConvert.DeserializeObject<List<Lab>>(json);
        }
        //  Console.WriteLine(Computers.Count);     // USED FOR MANUAL DEBUGGING

        return Labs;
    }
    public void UpdateComputer()
    {
        using StreamWriter writer = new(FilePathComputers);
        string update = JsonConvert.SerializeObject(_computers, Formatting.Indented);
        writer.WriteLine(update);
    }
    public void UpdateLab()
    {
        using StreamWriter writer = new(FilePathLabs);
        string update = JsonConvert.SerializeObject(_labs, Formatting.Indented);
        writer.WriteLine(update);
    }


    public static string ConvertToJson(string[,] matrix)
    {
        // Creare un oggetto JArray per la conversione
        JArray jsonArray = new();

        // Ottieni le dimensioni della matrice
        int rows = matrix.GetLength(0);
        int columns = matrix.GetLength(1);

        // Popola l'oggetto JArray con i dati della matrice
        for (int i = 0; i < rows; i++)
        {
            JArray jsonRow = new();

            for (int j = 0; j < columns; j++)
            {
                jsonRow.Add(matrix[i, j]);
            }

            jsonArray.Add(jsonRow);
        }

        // Serializza l'oggetto JArray in una stringa JSON formattata
        return jsonArray.ToString(Formatting.Indented);
    }

    public static string[,] ConvertFromJson(string jsonString)
    {
        // Deserializza la stringa JSON in un array JArray
        JArray jsonArray = JArray.Parse(jsonString);

        // Ottieni le dimensioni della matrice
        int rows = jsonArray.Count;
        int columns = jsonArray[0].Count();

        // Inizializza la matrice
        string[,] matrix = new string[rows, columns];

        // Popola la matrice con i dati dal JArray
        for (int i = 0; i < rows; i++)
        {
            JArray jsonRow = (JArray)jsonArray[i];

            for (int j = 0; j < columns; j++)
            {
                matrix[i, j] = jsonRow[j].ToString();
            }
        }

        return matrix;
    }


    /* public List<T> ReadFile(string path)
    {
        try
        {
            using (var myFile = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var streamReader = new StreamReader(myFile))
                {
                    string jsonContent = streamReader.ReadToEnd();
                    if (!string.IsNullOrEmpty(jsonContent))
                    {
                        if (jsonContent.StartsWith("["))
                        {
                            return JsonConvert.DeserializeObject<List<T>>(jsonContent);
                        }
                        else
                        {
                            T singleObject = JsonConvert.DeserializeObject<T>(jsonContent);
                            return new List<T> { singleObject };
                        }
                    }
                    else
                    {
                        return new List<T>();
                    }
                }
            }
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message);
            return new List<T>();
        }   

    }

    public void WriteJsonFile<T>(string filePath, T data, JsonWriter<T> jsonWriter)
    {
        string jsonData = jsonWriter(data, Formatting.Indented);
        File.WriteAllText(filePath, jsonData);
    }

} */

    /* public void ReadFile()
    {
        if (!File.Exists(_path))
        {
            _users = new List<User>();
            return;
        }

        using (var myFile = File.Open(_path, FileMode.Open))
        {
            using (var streamReader = new StreamReader(myFile))
            {
                _users = JsonConvert.DeserializeObject<List<User>>(streamReader.ReadToEnd());
            }
        }

    }
    
    public void WriteFile()
    {
        var text = JsonConvert.SerializeObject(_users);

        using (var myFile = File.Create(_path))
        {
            using (var streamWriter = new StreamWriter(myFile))
            {
                streamWriter.Write(text);
            }
        }

    } */

}
