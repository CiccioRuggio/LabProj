using System.Net.Security;
using UserNamespace;
using Newtonsoft.Json;
using System.ComponentModel;
using LabService;
using Newtonsoft.Json.Linq;
//using System.Text.Json;

namespace LabDatabase;
public class FileManager
{
    private static readonly string FilePath = "../LabService/Data/Labs.json";

    [JsonProperty]
    private List<Computer> _computers { get; set; }
    [JsonProperty]
    private List<Lab> _labs { get; set; }

    [JsonConstructor]
    public FileManager()
    {
        /* _computers = new();
        _labs = new();
        Computer c1 = new("Computer1", "First desc", "Main specs: i7 12th gen, 16gb RAM, nvidia GeForce RTX 2060ti", null, null, null);
        Computer c2 = new("Computer2", "Second desc", "Main specs: i5 9th gen, 8gb RAM, nvidia GeForce RTX 1070ti", null, null, null);
        Lab l1 = new();

        _computers.Add(c1);
        _computers.Add(c2);
        _labs.Add(l1);

        UpdateComputer();
        UpdateLab(); */

        _computers = LoadOrCreateComputers();
        _labs = LoadOrCreateLabs();
    }

    public List<Computer> GetComputers()
    {
        return _computers;
    }
    public List<Lab> GetLabs()
    {
        return _labs;
    }

    public Computer FindComputer(int id)
    {
        foreach (Computer Computer in _computers)
        {
            if (Computer.Id == id)
            {
                return Computer;
            }
        }
        return null;
    }

    public Lab FindLab(int id)
    {
        foreach (Lab Lab in _labs)
        {
            if (Lab.Id == id)
            {
                return Lab;
            }
        }
        return null;
    }

    public bool CheckComputerExistence(Computer computer)
    {
        if (computer != null && computer.Id != 0 /* && computer.Id != null */)
        {
            if (FindComputer(computer.Id) != null && FindComputer(computer.Id).Id == computer.Id)
                return true;
        }
        return false;
    }

    public bool CheckLabExistence(Lab lab)
    {
        if (lab != null && lab.Id != 0/*  && Computer.Id != null */)
        {
            if (FindLab(lab.Id) != null && FindLab(lab.Id).Id == lab.Id)
                return true;
        }
        return false;
    }

    public void LoadComputer()
    {
        using StreamReader reader = new(FilePath);
        string jsonread = reader.ReadToEnd();
        if (jsonread is not null)
            _computers = JsonConvert.DeserializeObject<List<Computer>>(jsonread);
    }
    public void LoadLab()
    {
        using StreamReader reader = new(FilePath);
        string jsonread = reader.ReadToEnd();
        if (jsonread is not null)
            _labs = JsonConvert.DeserializeObject<List<Lab>>(jsonread);
    }

    public static List<Computer> LoadOrCreateComputers()
    {
        List<Computer> Computers = new();
        if (!File.Exists(FilePath))
        {
            File.Create(FilePath).Close();
            return Computers;
        }

        string json = File.ReadAllText(FilePath);

        if (json.Length > 0)
        {
            Computers = JsonConvert.DeserializeObject<List<Computer>>(json);
        }
        //  Console.WriteLine(Computers.Count);     // USED FOR MANUAL DEBUGGING

        return Computers;
    }
    public static List<Lab> LoadOrCreateLabs()
    {
        List<Lab> Labs = new();
        if (!File.Exists(FilePath))
        {
            File.Create(FilePath).Close();
            return Labs;
        }

        string json = File.ReadAllText(FilePath);

        if (json.Length > 0)
        {
            Labs = JsonConvert.DeserializeObject<List<Lab>>(json);
        }
        //  Console.WriteLine(Computers.Count);     // USED FOR MANUAL DEBUGGING

        return Labs;
    }
    public void UpdateComputer()
    {
        using StreamWriter writer = new(FilePath);
        string update = JsonConvert.SerializeObject(_computers, Formatting.Indented);
        writer.WriteLine(update);
    }
    public void UpdateLab()
    {
        using StreamWriter writer = new(FilePath);
        string update = JsonConvert.SerializeObject(_labs, Formatting.Indented);
        writer.WriteLine(update);
    }
}