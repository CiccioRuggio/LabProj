using Newtonsoft.Json;
using LabDatabase;
using LabService;
using UserNamespace;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Data.SqlTypes;
// using System.Text.Json;
// using System.Text.Json.Serialization;

public class Computer
{
    private static int _lastId = 0;
    [JsonProperty]
    //[JsonPropertyOrder(0)]
    public int Id { get; private set; }
    [JsonProperty]
    public int LabId { get; set; }
    [JsonProperty]
    public static DateOnly CreationDate { get; private set; }
    [JsonProperty]
    public string? Name { get; private set; }
    [JsonProperty]
    public string? Description { get; private set; }
    [JsonProperty]
    public string? Specifics { get; private set; }
    [JsonProperty]
    public string? Status { get; private set; }
    //[JsonConverter (typeof(StringMatrixConverter))]

    /* public string CalendarToString
    {
        get
        {
            if (Calendar != null)
            {
                return ConvertToJson(Calendar);
            }
            else return ConvertToJson(InitializeCalendar());
        }
        set
        {
            if (Calendar != null) ConvertToJson(Calendar);
        }
    } */

    //[JsonConverter (typeof(StringMatrixConverter))]
    //[JsonPropertyName("Calendar")]
    [JsonProperty]
    public Dictionary<string, Dictionary<string, string>>? Calendar { get; set; }
    /* {
        get
        {
            if (CalendarToString != null)
            {
                return ConvertFromJson(CalendarToString);
            }
            else return InitializeCalendar();
        }
        set
        {
            if (CalendarToString != null) ConvertFromJson(CalendarToString);
        }
    } */
    [JsonConstructor]
    public Computer(string name, string desc, string specs, string? status, Dictionary<string, Dictionary<string, string>>? calendar, string? creationDate, int labId)
    {
        try
        {
            Id = ++_lastId;
            Name = name;
            LabId = labId;
            Description = desc;
            Specifics = specs;
            if (status != null && CheckStatus(status))
                Status = status;
            else Status = "available";
            if (calendar != null)
                Calendar = calendar;
            else
                Calendar = InitializeCalendar();
            if (creationDate != null && _CreationDateCheck(creationDate))
                CreationDate = DateOnly.FromDateTime(DateTime.Parse(creationDate));
            //  NOTE:   THERE'S ALREADY AN EXCEPTION FOR THE WRONG DateOnly FORMAT, SO IF A STRING PASSES THE _CreationDateCheck() 
            //          BUT IS IN A WRONG FORMAT THE SYSTEM WILL THROW AN EXCEPTION, OTHERWISE HE GOES THROUGH AND PARSE IT
            //          (OR TAKES THE DateTime.Now VALUE PARSED IN DateOnly)
            else CreationDate = DateOnly.FromDateTime(DateTime.Now);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }

    //public Computer() { }

    private static Dictionary<string, Dictionary<string, string>> InitializeCalendar()
    {
        Dictionary<string, string> Booking = new()
        {
            { "09-10", "available" },
            { "10-11", "available" },
            { "11-12", "available" },
            { "12-13", "available" },
            { "13-14", "available" },
            { "14-15", "available" },
            { "15-16", "available" },
            { "16-17", "available" },
            { "17-18", "available" }
        };
        Dictionary<string, Dictionary<string, string>> Calendar = new()
        {
            { "Monday", Booking },
            { "Tuesday", Booking },
            { "Wednesday", Booking },
            { "Thursday", Booking },
            { "Friday", Booking }
        };

        // Calendar[0, 0] = "NOT BOOKABLE";
        // Calendar[1, 0] = "Monday";
        // Calendar[2, 0] = "Tuesday";
        // Calendar[3, 0] = "Wednesday";
        // Calendar[4, 0] = "Thursday";
        // Calendar[5, 0] = "Friday";

        // Calendar[0, 1] = "9-10";
        // Calendar[0, 2] = "10-11";
        // Calendar[0, 3] = "11-12";
        // Calendar[0, 4] = "12-13";
        // Calendar[0, 5] = "13-14";
        // Calendar[0, 6] = "14-15";
        // Calendar[0, 7] = "15-16";
        // Calendar[0, 8] = "16-17";
        // Calendar[0, 9] = "17-18";

        // for (int i = 1; i < Calendar.GetLength(0); i ++)
        // {
        //     for (int j = 1; j < Calendar.GetLength(1); j++)
        //     {
        //         if (Calendar[i,j] == null)
        //             {Calendar[i,j] = "available";}
        //         else 
        //             {Calendar[i,j] = null;}
        //     }
        // }
        
        return Calendar;
    }

    private static bool CheckWeekday(string weekDay)
    {
        Dictionary<string, Dictionary<string, string>> Calendar = InitializeCalendar();
        /* for (int i = 1; i >= 1 && i < Calendar.GetLength(0); i++)
        {
            if (weekDay == Calendar[i, 0])
                return true;
        } */
        foreach (string day in Calendar.Keys)
        {
            if (day == weekDay)
            {
                return true;
            }
        }
        return false;
    }
    private static bool CheckTimeSlot(string timeSlot)
    {
        /* string[,] Calendar = InitializeCalendar();
        for (int i = 1; i >= 1 && i < Calendar.GetLength(1); i++)
        {
            if (timeSlot == Calendar[0, i])
                return true;
        } */
        Dictionary<string, Dictionary<string, string>> Calendar = InitializeCalendar();

        foreach (string day in Calendar.Keys)
        {
            foreach (string hour in Calendar[day].Keys)
            {
                if (hour == timeSlot)
                {
                    return true;
                }
            }
        }
        return false;
    }

    private static bool CheckStatus(string stat)
    {
        if (stat == "working" || stat == "maintenance" || stat == "out of order" || stat == "removed" || stat == "reserved" || stat == "available")
        {
            return true;
        }
        else throw new Exception("STATUS NOT CORRECT");
    }
    private static bool _CreationDateCheck(string creationDate)
    {
        if (creationDate != null && creationDate.Length >= 8 && creationDate.Length <= 10) return true;
        else return false;
    }


    public void InsertCalendar(string userEmail, string weekDay, string timeSlot)
    {
        if (Lab.GetAuthorizedUser(userEmail) && CheckWeekday(weekDay) && CheckTimeSlot(timeSlot) && Calendar != null)
        {
            /* int dayIndex = 0;
            int hourIndex = 0;
            for (int row = 1; Calendar != null && row < Calendar.GetLength(0); row++)
            {
                if (weekDay == Calendar[row, 0])
                {
                    dayIndex = row;
                    break;
                }
            }
            for (int row = 1; Calendar != null && row < Calendar.GetLength(1); row++)
            {
                if (timeSlot == Calendar[0, row])
                {
                    hourIndex = row;
                    break;
                }
            }
            if (dayIndex > 0 && hourIndex > 0)
            {
                if (Calendar != null && Calendar[dayIndex, hourIndex] == "available")
                {
                    Calendar[dayIndex, hourIndex] = userEmail;
                }
                else throw new Exception("TIMESLOT ALREADY BOOKED");
            }
            else throw new Exception("NOT ABLE TO FIND SPECIFIED TIMESLOT AND DAY"); */
            /* foreach (string day in Calendar.Keys)
            {
                if (day == weekDay)
                {
                    foreach (string hour in Calendar[day].Keys)
                    {
                        if (hour == timeSlot && Calendar[day][hour] == "available")
                        {
                            Calendar[day][hour] = userEmail;
                        }
                        else throw new Exception("TIMESLOT NOT VERIFIED");
                    }
                }
                else throw new Exception("WEEKDAY NOT VERIFIED");
            } */

            if (Calendar[weekDay][timeSlot] == "available") Calendar[weekDay][timeSlot] = userEmail;
            else throw new Exception($"CAN'T BOOK, THAT SPECIFIED TIMESLOT AND DAY IS: {Calendar[weekDay][timeSlot].ToUpper()}!");
        }
        else throw new Exception("USER NOT AUTHORIZED OR WRONG DAY SPECIFIED OR WRONG TIMESLOT SPECIFIED");
    }

    public void ClearCalendar()
    {
        Calendar = InitializeCalendar();
    }
}