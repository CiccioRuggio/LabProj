using UserNamespace;
using LabDatabase;
using Newtonsoft.Json;
//using System.Text.Json.Serialization;

namespace LabService;

public class Lab
{
    [JsonProperty]
    public List<Computer>? Computers { get; set; }
    [JsonProperty]
    public string? Name { get; set; }

    //  NOTE FROM 11-15: IF THE List<User> DOESN'T WORK FINE I MAY ONLY USE A List<string> AND SAVE USERS' EMAIL
    private static readonly List<User> _authorizedUsers = new()
    {
        new ("michele.malgeri@unict.it", "Michele", "Malgeri", "MipiaceC#", "labAdmin", "2023-11-13"),
        new ("ciccio.ruggeri@tiscali.it", "Francesco", "Ruggeri", "MiPiaceUnreal", "labAdmin", "2023-11-15")
    };
    private static int _lastId = 0;
    [JsonProperty]
    //[JsonPropertyOrder(0)]
    public int Id { get; set; }

    public static bool GetAuthorizedUser(string email)
    {
        if (_authorizedUsers != null && _authorizedUsers.Count > 0)
        {
            foreach (User u in _authorizedUsers)
            {
                if (u.Email == email)
                {
                    return true;
                }
                throw new Exception("EMAIL NOT IN AUTHORIZED DB");
            }
        }
        throw new Exception("NO AUTHORIZED USERS");
    }
    public Lab()
    {
        /* FileManager FileM = new();
        if (FileM.CheckLabExistence(FileM.FindLab(Id)))
            Computers = FileM.FindLab(Id).Computers;
        else  */
        string pcPath = "../LabService/Data/Computers.json";
        List<Computer> Computerss = new()
        {
            new("Computer1", "First desc", "Main specs: i7 12th gen, 16gb RAM, nvidia GeForce RTX 2060ti", null, null, null, 1),
            new("Computer2", "Second desc", "Main specs: i5 9th gen, 8gb RAM, nvidia GeForce RTX 1070ti", null, null, null, 1)
        };
        if (!System.IO.File.Exists(pcPath))
        {
            System.IO.File.Create(pcPath).Close();
        }

        string jsonPc = JsonConvert.SerializeObject(Computerss, Formatting.Indented);
        System.IO.File.WriteAllText(pcPath, jsonPc);

        string jsonGetPc = System.IO.File.ReadAllText(pcPath);
        var computers = JsonConvert.DeserializeObject<List<Computer>>(jsonGetPc);
        if (computers != null && computers.Count > 0) Computers = computers;
        else
        Computers = Computerss;
        Id = ++_lastId;
        Name = $"Lab{Id}";
    }
}
