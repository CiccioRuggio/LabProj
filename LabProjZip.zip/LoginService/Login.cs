namespace LoginService;

using System.Security.Principal;
using UserNamespace;
//using UserService;

public class Token
{
    public User? user { get; set; }
    public string? challenge { get; set; }

    public Token(User user, string challenge)
    {
        if (user != null && challenge.Length != 0)
        {
            this.user = user;
            this.challenge = challenge;
        }
    }
}

public class Login
{
    public bool logged;

    public Login(Token token)
    {
        if (token.user != null && token.challenge.Length != 0)
        {
            logged = true;
        }
        logged = false;
    }

    private string GenerateChallenge(User user)
    {
        if (user != null)
        {
            Random rand = new();
            int num = rand.Next();
            return $"{user.Email}-_-" + num;
        }
        return "0";
    }

    private static Token GenerateToken()
    {
        return new Token(new User("", "", "", "", ""), "0");
    }

}