using Microsoft.AspNetCore.Mvc;
using LabDatabase;
using Newtonsoft.Json;

namespace LabService.Controllers;

[ApiController]
[Route("[controller]")]
public class LabController : ControllerBase
{
    /* private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    private readonly ILogger<WeatherForecastController> _logger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _logger = logger;
    }

    [HttpGet(Name = "GetWeatherForecast")]
    public IEnumerable<WeatherForecast> Get()
    {
        return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        {
            Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();
    } */

    private static FileManager FileM = new();
    private static List<Lab> _labs = FileM.GetLabs();
    private static List<Computer> _computers = FileM.GetComputers();

    [HttpGet]

    public IActionResult GetComputersList()
    {
        // FileM.UpdateComputer();
        // FileM.UpdateLab();
        // FileM.LoadComputer();
        // FileM.LoadLab();
        // return Ok(_labs);
        string pcPath = "../LabService/Data/Computers.json";
        string labPath = "../LabService/Data/Labs.json";
        List<Computer> Computers = new()
        {
            new("Computer1", "First desc", "Main specs: i7 12th gen, 16gb RAM, nvidia GeForce RTX 2060ti", null, null, null, 1),
            new("Computer2", "Second desc", "Main specs: i5 9th gen, 8gb RAM, nvidia GeForce RTX 1070ti", null, null, null, 1)
        };
        if (!System.IO.File.Exists(pcPath))
        {
            System.IO.File.Create(pcPath).Close();
        }

        string jsonPc = JsonConvert.SerializeObject(Computers, Formatting.Indented);
        System.IO.File.WriteAllText(pcPath, jsonPc);

        string jsonGetPc = System.IO.File.ReadAllText(pcPath);
        var computers = JsonConvert.DeserializeObject<List<Computer>>(jsonGetPc);

        List<Lab> Labs = new()
        {
            new(),
            new()
        };
        if (!System.IO.File.Exists(labPath))
        {
            System.IO.File.Create(labPath).Close();
        }

        string jsonLab = JsonConvert.SerializeObject(Labs, Formatting.Indented);
        System.IO.File.WriteAllText(labPath, jsonLab);

        string jsonGetLab = System.IO.File.ReadAllText(labPath);
        var labs = JsonConvert.DeserializeObject<List<Lab>>(jsonGetLab);

        // if (_labs != null && _computers != null && _labs.Count > 0 && _computers.Count > 0)
        // {
        //     FileM.LoadComputer();
        //     FileM.LoadLab();
        //     FileM.UpdateComputer();
        //     FileM.UpdateLab();
        //     return Ok(_labs);
        // }
        // return NotFound("LABS NOT FOUND");

        return Ok(labs);
    }

    [HttpDelete]
    [Route("{labId}/{adminMail}")]

    public IActionResult DeleteLab(int labId, string adminMail)
    {
        if (_labs != null && _labs.Count > 0)
        {
            if (Lab.GetAuthorizedUser(adminMail))
            {
                int i = _labs.IndexOf(FileM.FindLab(labId));
                _labs.RemoveAt(i);
                FileM.UpdateLab();
                return Ok("LAB TERMINATED");
            }
            else return NotFound("MAIL NOT VERIFIED");
        }
        else return NotFound(_labs);
    }

    [HttpDelete]
    [Route("{pcId}/{adminMail}")]

    public IActionResult DeleteComputer(int pcId, string adminMail)
    {
        if (_computers != null && _computers.Count > 0)
        {
            if (Lab.GetAuthorizedUser(adminMail))
            {
                int i = _computers.IndexOf(FileM.FindComputer(pcId));
                _computers.RemoveAt(i);
                FileM.UpdateComputer();
                return Ok("COMPUTER TERMINATED");
            }
            else return NotFound("MAIL NOT VERIFIED");
        }
        else return NotFound(_computers);
    }
}
