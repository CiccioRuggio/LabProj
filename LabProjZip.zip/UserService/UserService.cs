using UserNamespace;
using UserDatabase;

public class Login
{
    private static FileManager? _fileM { get; set; }
    private static List<User>? _users { get; set; }

    private static void LoadUsers()
    {
        //  HERE WE VERIFY IF _users IS EMPTY OR NOT, IF IT'S THEN WE CREATE A NEW ISTANCE AND ASSIGN IT TO THE FIELD
        if (_users == null || _users.Count == 0) { _users = new(); }

        //  HERE WE VERIFY IF _fileM IS NOT EMPTY, SO WE CAN WORK WITH IT
        if (_fileM != null)
        {
            //  HERE WE VERIFY IF FileManager HAS A PROPER LIST OF USERS TO WORK WITH
            if (_fileM.GetUsers() != null && _fileM.GetUsers().Count > 0)
            {
                foreach (User u in _fileM.GetUsers())
                {
                    _users.Add(u);
                }
            }
        }
    }

    public Login()
    {
        _fileM = new();
        LoadUsers();
    }

    public int GenerateChallenge(string email)
    {
        foreach (User user in _users)
        {
            if (user.Email == email)
            {
                Random rand = new();
                int num = rand.Next();
                return num;
            }
        }

        return 0;
    }

    public string GenerateToken()
    {
        return "";
    }
}