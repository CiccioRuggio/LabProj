using UserNamespace;
using LabDatabase;
using Newtonsoft.Json;

namespace LabService;

public class Lab
{
    [JsonProperty]
    public List<Computer>? Computers { get; private set; }
    
    //  NOTE FROM 11-15: IF THE List<User> DOESN'T WORK FINE I MAY ONLY USE A List<string> AND SAVE USERS' EMAIL
    private static readonly List<User> _authorizedUsers = new()
    {
        new ("michele.malgeri@unict.it", "Michele", "Malgeri", "MipiaceC#", "labAdmin", "2023-11-13"),
        new ("ciccio.ruggeri@tiscali.it", "Francesco", "Ruggeri", "MiPiaceUnreal", "labAdmin", "2023-11-15")
    };
    private static int _lastId = 0;
    [JsonProperty]
    public int Id { get; set; }

    public static bool GetAuthorizedUser(string email)
    {
        if (_authorizedUsers != null && _authorizedUsers.Count > 0)
        {
            foreach (User u in _authorizedUsers)
            {
                if (u.Email == email)
                {
                    return true;
                }
                throw new Exception("EMAIL NOT IN AUTHORIZED DB");
            }
        }
        throw new Exception("NO AUTHORIZED USERS");
    }

    [JsonConstructor]
    public Lab(){
        Id = ++_lastId;
        Computers = FileManager.LoadOrCreateComputers();
    }
}
