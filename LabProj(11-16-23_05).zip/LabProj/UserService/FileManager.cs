using System.Net.Security;
using UserNamespace;
using Newtonsoft.Json;
using System.ComponentModel;

namespace UserDatabase;
public class FileManager
{
    private static readonly string FilePath = "../UserService/Data/Users.json";
    [JsonProperty]
    private List<User> _users { get; set; }

    [JsonConstructor]
    public FileManager()
    {
        /* _users = new();

        User user2 = new ("marco.grassia@unict.it", "Marco", "Grassia", "miPiaceJS", "teacher");
        _users.Add(user2);

        UpdateUser(); */
        _users = LoadOrCreateUsers();
    }

    public List<User> GetUsers()
    {
        return _users;
    }

    public User Find(string email)
    {
        foreach (User user in _users)
        {
            if (user.Email == email)
            {
                return user;
            }
        }
        return null;
    }

    public bool CheckUserExistence(User user)
    {
        if (user != null && user.Email != null && user.Email != "WRONG FORMAT EMAIL")
        {
            if (Find(user.Email) != null && Find(user.Email).Email == user.Email)
                return true;
        }
        return false;
    }

    public void LoadUser()
    {
        using StreamReader reader = new(FilePath);
        string jsonread = reader.ReadToEnd();
        if (jsonread is not null)
            _users = JsonConvert.DeserializeObject<List<User>>(jsonread);
    }
    public static List<User> LoadOrCreateUsers()
    {
        //string path = "../UserService/Data/Users.json";

        List<User> users = new();
        if (!File.Exists(FilePath))
        {
            File.Create(FilePath).Close();
            return users;
        }

        string json = File.ReadAllText(FilePath);

        if (json.Length > 0)
        {
            users = JsonConvert.DeserializeObject<List<User>>(json);
        }
        //  Console.WriteLine(users.Count);     // USED FOR MANUAL DEBUGGING

        return users;
    }
    public void UpdateUser()
    {
        using StreamWriter writer = new(FilePath);
        string update = JsonConvert.SerializeObject(_users, Formatting.Indented);
        writer.WriteLine(update);
    }

    public int GenerateChallenge(string email)
    {
        int num = GenerateNonce();
        if (Find(email) != null)
        {
            return email.Length * num + DateTime.Now.Minute;        //Adding minutes is needed to know when the token expires
        }
        return 0;
    }

    private static int GenerateNonce()
    {
        Random rand = new();
        int num = rand.Next(1, 10);
        return num;
    }
}