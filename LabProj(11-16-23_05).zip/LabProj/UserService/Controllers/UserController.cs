using Microsoft.AspNetCore.Mvc;
using UserNamespace;
using UserDatabase;
using System.Reflection.Metadata.Ecma335;

namespace UserService.Controllers;

[ApiController]
[Route("[controller]")]
public class UserController : ControllerBase
{
    private static FileManager FileM = new();
    private static List<User> _users = FileM.GetUsers();

    [HttpGet]
    //  WORKS FINE
    public IActionResult GetUsersList()
    {
        //Console.WriteLine(_users.Count);  //USED JUST FOR MANUAL DEBUG

        if (_users != null && _users.Count >= 1)
        {
            FileM.LoadUser();
            FileM.UpdateUser();
            return Ok(_users);
        }
        return NotFound();
    }

    [HttpGet]
    [Route("{email}", Name = "Challenge")]
    public IActionResult GenerateChallengeController(string email)
    {
        int challengeInt = FileM.GenerateChallenge(email);
        //  IF THIS METHOD RETURNS A Challenge (INT VALUE) DIFFERENT FROM 0 THE PROCESS WILL GO THROUGH
        if (challengeInt != 0)
        {
            string pswChall = FileM.Find(email).PswChallenge(challengeInt);    //USER METHOD TO GENERATE A string RESULTING FROM USER PSW AND CHALLENGE
            if (pswChall != null && pswChall != "Not valid")
            {
                string[] challengeArr = new string[pswChall.Length];

                //Console.WriteLine(challenge);     //  USED FOR MANUAL DEBUGGING

                for (int i = 0; i < challengeArr.Length; i++)
                {
                    challengeArr[i] = (pswChall[i].GetHashCode() * challengeInt).ToString();
                }

                string challenge = "";
                foreach (string s in challengeArr) challenge += s;

                return Ok(DateTime.Now/* .ToString("HH:mm") */ + $"////{challenge}");
            }
        }
        return NotFound();
    }

    [HttpGet]
    [Route("{email}/{password}")]
    public IActionResult Login(string email, string password)
    {
        string p = UserNamespace.User.ComputeSha256Hash(password);
        //Console.WriteLine(UserNamespace.User.ComputeSha256Hash(p));
        try
        {
            User user = new(email, p);
            if (FileM.CheckUserExistence(user))
                return Ok(user.Password);       // QUI VA RESTITUITA LA CHALLENGE
            else return NotFound();
        }
        catch (Exception e)
        {
            return NotFound(e.Message);
        }
    }

    [HttpDelete]
    [Route("{email}/{adminMail}")]
    //  WORKS FINE
    public IActionResult DeleteUser(string email, string adminMail)
    {
        if (_users != null && _users.Count >= 1)
        {
            if (FileM.Find(adminMail).Role == "userAdmin")
            {
                int i = _users.IndexOf(FileM.Find(email));
                _users.RemoveAt(i);
                FileM.UpdateUser();
                return Ok("User TERMINATED");
            }
            else return NotFound(adminMail);
        }
        else return NotFound(_users);
    }

    [HttpPost]
    [Route("{name}/{surname}/{email}/{password}/{role}")]
    public IActionResult AddUser(string name, string surname, string email, string password, string role)
    {
        User user = new(email, name, surname, password, role, null);
        if (_users != null)
        {
            if (!FileM.CheckUserExistence(user))
            {
                _users.Add(user);
                FileM.UpdateUser();
                return Ok(user);
            }
            else return NotFound("USER ALREADY PRESENT IN DB");
        }
        return NotFound("NO DB FOUND");
    }

    [HttpPut]
    [Route("{name}/{surname}/{email}/{password}/{role}/{existingEmail}")]
    public IActionResult UpdateNewUser(string name, string surname, string password, string email, string role, string existingEmail)
    {
        User user = new(email, name, surname, password, role, null);
        if (_users != null)
        {
            if (!FileM.CheckUserExistence(user))
            {
                if (FileM.Find(existingEmail).Email != user.Email)
                {
                    int i = _users.IndexOf(FileM.Find(existingEmail));
                    _users.RemoveAt(i);
                    _users.Add(user);
                    FileM.UpdateUser();
                    return Ok();
                }
            }
            else return NotFound("USER NOT FOUND");
        }
        return NotFound("NO DB FOUND");
    }
}
