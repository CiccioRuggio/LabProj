using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using System;

public class StringMatrixConverter : JsonConverter<string[,]>
{
    public override string[,] ReadJson(JsonReader reader, Type objectType, string[,] existingValue, bool hasExistingValue, JsonSerializer serializer)
    {
        JArray array = JArray.Load(reader);
        int rows = array.Count;
        int columns = array[0].Count();

        string[,] result = new string[rows, columns];

        for (int i = 0; i < rows; i++)
        {
            JArray row = (JArray)array[i];
            for (int j = 0; j < columns; j++)
            {
                result[i, j] = row[j].ToObject<string>();
            }
        }

        return result;
    }

    public override void WriteJson(JsonWriter writer, string[,] value, JsonSerializer serializer)
    {
        var rows = value.GetLength(0);
        var columns = value.GetLength(1);

        var jsonArray = new JArray();

        for (var i = 0; i < rows; i++)
        {
            var rowArray = new JArray();
            for (var j = 0; j < columns; j++)
            {
                rowArray.Add(value[i, j]);
            }
            jsonArray.Add(rowArray);
        }

        jsonArray.WriteTo(writer);
    }
}
