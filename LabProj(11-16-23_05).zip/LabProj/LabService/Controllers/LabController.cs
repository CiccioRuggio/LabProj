using Microsoft.AspNetCore.Mvc;
using LabDatabase;
using LabService;
using UserNamespace;

namespace LabService.Controllers;

[ApiController]
[Route("[controller]")]
public class LabController : ControllerBase
{
    /* private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    private readonly ILogger<WeatherForecastController> _logger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _logger = logger;
    }

    [HttpGet(Name = "GetWeatherForecast")]
    public IEnumerable<WeatherForecast> Get()
    {
        return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        {
            Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();
    } */

    private static FileManager FileM = new();
    private static List<Lab> _labs = FileM.GetLabs();
    private static List<Computer> _computers = FileM.GetComputers();

    [HttpGet]

    public IActionResult GetLabsList()
    {
        if (_labs != null && _computers != null && _labs.Count > 0 && _computers.Count > 0)
        {
            FileM.LoadComputer();
            FileM.LoadLab();
            FileM.UpdateComputer();
            FileM.UpdateLab();
            return Ok(_labs);
        }
        return NotFound("LABS NOT FOUND");
    }

    [HttpDelete]
    [Route("{labId}/{adminMail}")]

    public IActionResult DeleteLab(int labId, string adminMail)
    {
        if (_labs != null && _labs.Count > 0)
        {
            if (Lab.GetAuthorizedUser(adminMail))
            {
                int i = _labs.IndexOf(FileM.FindLab(labId));
                _labs.RemoveAt(i);
                FileM.UpdateLab();
                return Ok("LAB TERMINATED");
            }
            else return NotFound("MAIL NOT VERIFIED");
        }
        else return NotFound(_labs);
    }

    [HttpDelete]
    [Route("{pcId}/{adminMail}")]

    public IActionResult DeleteComputer(int pcId, string adminMail)
    {
        if (_computers != null && _computers.Count > 0)
        {
            if (Lab.GetAuthorizedUser(adminMail))
            {
                int i = _computers.IndexOf(FileM.FindComputer(pcId));
                _computers.RemoveAt(i);
                FileM.UpdateComputer();
                return Ok("COMPUTER TERMINATED");
            }
            else return NotFound("MAIL NOT VERIFIED");
        }
        else return NotFound(_computers);
    }


}
