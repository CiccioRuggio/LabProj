namespace UserNamespace;

using System.Data.Common;
using System.Net.Http.Headers;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography;
using System.Text;
using UserDatabase;
using Newtonsoft.Json;
//using Database;

public class User
{
    [JsonProperty]
    public DateOnly CreationDate { get; private set; }
    private string? _role;
    [JsonProperty]
    public string? Role
    {
        get
        {
            if (_role != null)
            {
                return _role;
            }
            return "Role not given";
        }
        set
        {
            // RUOLO NON NECESSARIO, GLI UTENTI "SPECIALI" AUTORIZZATI VANNO AGGIUNTI IN UNA LISTA PRESENTE NELL'APP RELATIVA (ex. LabAdmin saranno gli utenti della lista in Lab; UserAdmin saranno gli utenti della lista in UserService)
            if (value != null)
            {
                if (_RoleCheck(value))
                {
                    _role = value;
                }
            }
            else _role = "Wrong role given";
        }
    }
    //private static int _lastId = 0;
    //public int Id { get; private set; }
    [JsonProperty]
    public string? Name { get; set; }
    [JsonProperty]
    public string? Surname { get; set; }
    [JsonProperty]
    public string? Email { get; set; }
    //[JsonProperty]
    private string? _password;
    private static readonly string _requiredChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    //private static readonly char[] requiredChars = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
    [JsonProperty]
    public string Password
    {
        get
        {
            if (_password != null && _password.Length != 64/* && _nonce != 0 */)
            {
                return ComputeSha256Hash(_password);
            }
            else if (_password.Length == 64) return _password;
            return "Password not given";
        }
        set
        {
            if (_PasswordCheck(value))
            {
                _password = /* _nonce + */ value /* + _nonce */;
                //_password = ComputeSha256Hash(_password);       //  COMMENTING THIS LINE CAN LET US SEE WHAT IS PASSED TO THE HASHING METHOD
            }
        }
    }

    /* private int _nonce;
    public int Nonce
    {
        get
        {
            if (_nonce != 0) return _nonce;
            return 0;
        }
        set
        {
            if (GenerateNonce() != 0)
            {
                _nonce = GenerateNonce();
            }
        }
    } */

    [JsonConstructor]
    public User(string email, string name, string surname, string password, string role, string? creationDate)
    {
        //_lastId++;
        //Id = ++_lastId;
        //Nonce = GenerateNonce();

        if (creationDate != null && _CreationDateCheck(creationDate)) CreationDate = DateOnly.FromDateTime(DateTime.Parse(creationDate));
        //  NOTE: THERE'S ALREADY AN EXCEPTION FOR THE WRONG DateOnly FORMAT, SO IF A STRING PASSES THE _CreationDateCheck() 
        //  BUT IS IN A WRONG FORMAT THE SYSTEM WILL THROW AN EXCEPTION, OTHERWISE HE GOES THROUGH AND PARSE IT (OR TAKES THE DateTime.Now VALUE PARSED IN DateOnly)
        else CreationDate = DateOnly.FromDateTime(DateTime.Now);
        Name = name;
        Surname = surname;
        if (_EmailCheck(email))
            Email = email;
        else Email = "WRONG FORMAT EMAIL";
        if (_PasswordCheck(password))
            Password = password;
        else Password = "WRONG FORMAT PASSWORD";
        if (_RoleCheck(role))
            Role = role;
        else Role = "WRONG ROLE GIVEN";
    }

    public User(string email, string password)
    {
        FileManager FileM = new();
        if (_EmailCheck(email))
        {
            if(FileM.Find(email) == null) throw new Exception("EMAIL NOT FOUND");
            if (password == FileM.Find(email).Password)
            {
                //Console.WriteLine(FileM.Find(email));
                Name = FileM.Find(email).Name;
                Surname = FileM.Find(email).Surname;
                if (_CreationDateCheck(FileM.Find(email).CreationDate.ToString()))
                    CreationDate = FileM.Find(email).CreationDate;
                else CreationDate = DateOnly.FromDateTime(DateTime.Now);
                Email = email;
                Password = password;
                if (_RoleCheck(FileM.Find(email).Role))
                    Role = FileM.Find(email).Role;
                else Role = "WRONG ROLE GIVEN";
            }
            else throw new Exception ("PASSWORD NOT VERIFIED");
        }
        else throw new Exception("EMAIL NOT IN CORRECT FORMAT");
    }

    /* private static int GenerateNonce()
    {
        Random rand = new();
        int num = rand.Next();
        return num;
    } */
    /* public int GetNonce()
    {
        return _nonce;
    } */
    /* public bool GetPassword(string psw)
    {
        return $"{_nonce}" + psw + $"{_nonce}" == _password;
    } */

    public override string ToString()
    {
        return  //$"Id: {Id};\n" +
                $"Email: {Email};\n" +
                $"Name: {Name} {Surname};\n" +
                $"Password: {Password};\n" +
                $"Date of Registration: {CreationDate};\n";
    }

    public static string ComputeSha256Hash(string rawData)
    {
        // Create a SHA256
        using (SHA256 sha256Hash = SHA256.Create())
        {
            // ComputeHash - returns byte array
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

            // Convert byte array to a string
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }

    public string PswChallenge(int challenge)
    {
        string ret = "";
        if (ValidateChallengeNum(challenge))
        {
            return ret += _password + $"{challenge}";
        }

        return "Not valid";
    }

    private bool ValidateChallengeNum(int challenge)
    {
        if (
                challenge >= Email.Length * 1 + DateTime.Now.Minute ||
                challenge >= Email.Length * 2 + DateTime.Now.Minute ||
                challenge >= Email.Length * 3 + DateTime.Now.Minute ||
                challenge >= Email.Length * 4 + DateTime.Now.Minute ||
                challenge >= Email.Length * 5 + DateTime.Now.Minute ||
                challenge >= Email.Length * 6 + DateTime.Now.Minute ||
                challenge >= Email.Length * 7 + DateTime.Now.Minute ||
                challenge >= Email.Length * 8 + DateTime.Now.Minute ||
                challenge >= Email.Length * 9 + DateTime.Now.Minute ||
                challenge >= Email.Length * 10 + DateTime.Now.Minute

                ||

                challenge <= Email.Length * 1 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 2 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 3 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 4 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 5 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 6 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 7 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 8 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 9 + DateTime.Now.Minute + 5 ||
                challenge <= Email.Length * 10 + DateTime.Now.Minute + 5
            )
        {
            return true;
        }
        return false;
    }


    //  ALL CHECK METHODS
    private static bool _PasswordCheck(string psw)
    {
        if (psw != null /* && _nonce != 0 */)
        {
            if (psw.Length == 64) return true;
            if (psw.Length > 24) throw new Exception("Passowrd too long, max 24 chars");
            else if (psw.Length < 8) throw new Exception("Passowrd too short, min 8 chars");
            int verChar = 0;
            foreach (char c in _requiredChars)
            {
                if (psw.Contains(c))
                {
                    verChar++;
                }
            }
            if (verChar == 0) throw new Exception("Password does not contain an uppercase character, please use at least 1");
            return true;
        }
        else return false;
    }
    private static bool _EmailCheck(string email)
    {
        if (email.Contains('@') && (email.EndsWith(".com") || email.EndsWith(".it"))) return true;
        else throw new Exception("WRONG EMAIL FORMAT - EXPECTING A '@' AND A '.com' or '.it' ENDING");
    }

    private static bool _CreationDateCheck(string creationDate)
    {
        if (creationDate != null && creationDate.Length >= 8 && creationDate.Length <= 10) return true;
        else return false;
    }
    private static bool _RoleCheck(string role)
    {
        if (role != null && (role == "regular" || role == "labAdmin" || role == "userAdmin" || role == "student" || role == "teacher"))
        {
            return true;
        }
        else return false;
    }
}
